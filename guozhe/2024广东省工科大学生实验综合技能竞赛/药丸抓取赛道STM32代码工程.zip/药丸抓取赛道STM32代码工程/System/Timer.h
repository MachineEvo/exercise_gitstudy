#ifndef __TIMER_H
#define __TIMER_H

void Timer1_Init(u16 arr,u16 psc);
void Timer2_Init(uint16_t ARR,uint16_t PSC);//M1:T2C3	M3:T2C4
void Timer3_Init(uint16_t ARR,uint16_t PSC);//M2:T3C3	M4:T3C4

#endif
