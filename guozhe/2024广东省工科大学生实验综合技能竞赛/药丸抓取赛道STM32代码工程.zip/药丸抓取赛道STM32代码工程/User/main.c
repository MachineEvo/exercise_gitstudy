#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Encoder.h"
#include "Key.h"
#include "Timer.h"
#include "W25Q64.h"
#include "menu.h"
#include "Stepper.h"
#include "Position.h"
#include "OPENMV.h"
#include "Serial.h"
#include "TB6612.h"
#include <stdlib.h>
#include <stdio.h>

//369mm		1855
//339mm		1704


//�ƶ����ȣ�0.1989325930685 mm
//����		5.0268283672537 mm**-1
#define	PRECISION	5.0268

//ҩ�����½ǿ�λ����
#define PLATE_Xmm	225//ҩ��X����
#define PLATE_Ymm	87//ҩ��Y����
#define PLATE_X		(int32_t)((float)PLATE_Xmm*PRECISION)//1130
#define PLATE_Y		(int32_t)((float)PLATE_Ymm*PRECISION)//440
#define PLATE_Gap	(int32_t)((float)40*PRECISION)

//ҩƿ��������
#define	BOTTLE_Xmm	111//ҩƿX����
#define BOTTLE_Ymm	117//ҩƿY����
#define BOTTLE_X	(int32_t)((float)BOTTLE_Xmm*PRECISION)//560
#define BOTTLE_Y	(int32_t)((float)BOTTLE_Ymm*PRECISION)//590

//ƿ����������
#define LID_Xmm		100//ƿ��X����
#define LID_Ymm		50//ƿ��Y����
#define LID_X		(int32_t)((float)LID_Xmm*PRECISION)
#define LID_Y		(int32_t)((float)LID_Ymm*PRECISION)

//������������Χ
#define PulseRange	3

//С���ȡ������Χ
#define BallErrorRange	40

//�������ʱ��
#define MaxMoveTime		400//��λ��s

//����һ��С��ץȡʱ��
#define MaxFirstBallGrapTime		150//��λ��s


//С����ɫʶ��˳��
#define FirstBallColor()	Color_blue()
#define SecondBallColor()	Color_red()

extern int16_t cx;
extern int16_t cy; 
extern int16_t ball_num; 


uint8_t DeveloperModelFLAG = 0,Statue_Control = 0,//״̬�����Ʋ���
		FPS = 0,FPS_CNT = 0,TIM1_CNT = 0,
		K_BAK = 0 , K_PSH = 0 , K_CON = 0,
		K_BAKcnt = 0,K_PSHcnt = 0,K_CONcnt = 0,
		Y_STEP = 8,
		TIM2_state = 0,TIM3_state = 0;
int16_t EncoderSpeed = 0;

uint32_t MoveTimeCnt = 0;


int32_t Ball_x = 0,Ball_y = 0;
uint8_t BallNum = 0;

StepperSettingDef M1SettingGlobal;
StepperSettingDef M2SettingGlobal;
StepperSettingDef M3SettingGlobal;
StepperSettingDef M4SettingGlobal;
uint8_t Gripper_state = DISABLE ;
uint32_t M1_ActualVelocity = 0 , M2_ActualVelocity = 0;
XYmoveDef XYmoveGlobal;
GripperMoveDef GripperMoveGlobal;


uint32_t	M1_GapCNT = 0 , M2_GapCNT = 0 , M3_GapCNT = 0 , M4_GapCNT = 0,
			M1_LastGap = 0 , M2_LastGap = 0 , M3_LastGap = 0 , M4_LastGap = 0 , 
			M1_PulseGap = 0 , M2_PulseGap = 0 , M3_PulseGap = 0 , M4_PulseGap = 0 , 
			M1_StartDistance = 0 , M2_StartDistance = 0 , M3_StartDistance = 0 , M4_StartDistance = 0 , 
			M1_TargetDistance = 0 , M2_TargetDistance = 0 , M3_TargetDistance = 0 , M4_TargetDistance = 0;

uint8_t M1_PulseControl = 0 , M2_PulseControl = 0 , M3_PulseControl = 0 , M4_PulseControl = 0;
int32_t M1_StartPoint = 0 , M2_StartPoint = 0 , M3_StartPoint = 0 , M4_StartPoint = 0;

extern 	uint16_t M1_ARR, M1_PSC,
				 M2_ARR, M2_PSC,
				 M3_ARR, M3_PSC,
				 M4_ARR, M4_PSC;
extern	uint8_t M1_State,
				M2_State,
				M3_State,
				M4_State;

//void BallNumCheck(int32_t Ball_X,int32_t Ball_Y)
//{
//	static int32_t Last_Ball_X = 0 , Last_Ball_Y = 0;
//	static uint8_t BallNum = 0;
//	
//	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_X)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_Y))){
//		
//	}else{
//		BallNum++;
//	}
//	
//	
//	Last_Ball_X = Ball_X;
//	Last_Ball_Y = Ball_Y;
//	switch(BallNum){
//		case 0:
//			break;
//		case 1:
//			goto BallGrap_1;
//			break;
//		case 2:
//			goto BallGrap_2;
//			break;
//		case 3:
//			goto BallGrap_3;
//			break;
//		case 4:
//			goto BallGrap_4;
//			break;
//		case 5:
//			goto BallGrap_5;
//			break;
//		case 6:
//			goto BallGrap_6;
//			break;
//	}
//}

int main(void)
{
	LED_Init();
	Key_Init();
	menu_Init();
	Encoder_Init();
	TB6612_Init();
	
	Timer1_Init(100,7200);//T = 10ms
	Serial_Init();
	Stepper_Init();
	
	
	XY_PositionReset(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	GripperPositionReset(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	M1SettingGlobal.StepperSellect = StepperM1;
	M1SettingGlobal.DivSellect = DIV4;
	
	M2SettingGlobal.StepperSellect = StepperM2;
	M2SettingGlobal.DivSellect = DIV4;
	
	M3SettingGlobal.StepperSellect = StepperM3;
	M3SettingGlobal.DivSellect = DIV4;
	
	M4SettingGlobal.StepperSellect = StepperM4;
	M4SettingGlobal.DivSellect = DIV4;
	
///////////////////////�ٶ�����////////////////////////
	XYmoveGlobal.MoveAcc = 	20;
	XYmoveGlobal.MoveSpeed =800;
	
	GripperMoveGlobal.ZmoveSpeed = 200;
	GripperMoveGlobal.RotateSpeed = 30;
//////////////////////////////////////////////////////
	
	GetBallPosition(&Ball_x,&Ball_y,&BallNum);

	Delay_s(1);
	if(K_BAKcnt){DeveloperModelFLAG = 1;
	LED_ON();Delay_ms(300);LED_OFF();Delay_ms(300);LED_ON();Delay_ms(300);LED_OFF();}
	else{DeveloperModelFLAG = 0;}
	K_BAKcnt = 0;
	
	Reset();						  //��λ��������openmv����ָ�ʹ���ػس�ʼ״̬
	Recognize_color();
	FirstBallColor();
	Recognize_ball();
	
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	Delay_s(3);

//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////��һ�ηּ�
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 || Ball_y == 0);
	
	static int32_t Last_Ball_X = 0 , Last_Ball_Y = 0;
	static uint8_t GrappedBallNum = 0;
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_1:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	
	
	
	
	
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////�ڶ��ηּ�
	
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_2:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X + PLATE_Gap;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////�����ηּ�
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_3:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X + 2*PLATE_Gap;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	

	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////���Ĵηּ�
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_4:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y + PLATE_Gap;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	
	
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////����ηּ�
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_5:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X + PLATE_Gap;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y + PLATE_Gap;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	
	
	
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////�����ηּ�
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
	if(BallErrorRange >= abs((int)(Last_Ball_X - Ball_x)) && BallErrorRange >=  abs((int)(Last_Ball_Y - Ball_y))){
		
	}else{
		GrappedBallNum++;
	}
	
	Last_Ball_X = Ball_x;
	Last_Ball_Y = Ball_y;
	switch(GrappedBallNum){
		case 0:
			break;
		case 1:
			goto BallGrap_1;
			break;
		case 2:
			goto BallGrap_2;
			break;
		case 3:
			goto BallGrap_3;
			break;
		case 4:
			goto BallGrap_4;
			break;
		case 5:
			goto BallGrap_5;
			break;
		case 6:
			goto BallGrap_6;
			break;
	}
	
BallGrap_6:
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	PLATE_X + 2*PLATE_Gap;//int32_t
	XYmoveGlobal.TargetY = 	PLATE_Y + PLATE_Gap;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	if(MoveTimeCnt > MaxFirstBallGrapTime){
		goto GrapBall_to_Bottle;
	}
	
	
	
GrapBall_to_Bottle:
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////ҩ���װ
	
	Reset();						  //��λ��������openmv����ָ�ʹ���ػس�ʼ״̬
	Recognize_color();
	SecondBallColor();
	Recognize_ball();
	
	static uint8_t BottleBallCnt=0;
do{
	
	do{
		GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	}while(Ball_x == 0 &&Ball_y == 0);
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	Ball_x;//int32_t
	XYmoveGlobal.TargetY = 	Ball_y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-50;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	A_DC_MotorRotation(0);
	B_DC_MotorRotation(0);

	PumpCmd(ENABLE);
	BoutCmd(ENABLE);
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	BOTTLE_X;//int32_t
	XYmoveGlobal.TargetY = 	BOTTLE_Y;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	PumpCmd(DISABLE);
	BoutCmd(DISABLE);
	Delay_s(1);
	
	BottleBallCnt++;
	GetBallPosition(&Ball_x,&Ball_y,&BallNum);
	
	if(MoveTimeCnt > MaxMoveTime){
		goto Stop_and_Reset;
	}
	
}while(BottleBallCnt < 6  || BallNum != 0);//  
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////��ƿ��2
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	BOTTLE_X;//int32_t
	XYmoveGlobal.TargetY = 	BOTTLE_Y-200;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////

	
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	Delay_s(1);
	
	GripperMoveGlobal.TargetZ = 		-600;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 		BOTTLE_X;//int32_t
	XYmoveGlobal.TargetY =		BOTTLE_Y+300;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	
	
	
	
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////��ƿ��
//	
//	
////////////////////////XY�ƶ�λ������/////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	XYmoveGlobal.TargetX = 	LID_X;//int32_t
//	XYmoveGlobal.TargetY = 	LID_Y;
//	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
//	StepperSetting(&M1SettingGlobal);
//	StepperSetting(&M2SettingGlobal);
///////////////////////////////////////////////////////////////
//	

////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-1180;//int32_t
//	GripperMoveGlobal.TargetRotate =	0;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-1180;//int32_t
//	GripperMoveGlobal.TargetRotate =	-100;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	

////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-0;//int32_t
//	GripperMoveGlobal.TargetRotate =	-100;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	Delay_s(1);
//	
//	GripperMoveGlobal.TargetZ = 		-1180;//int32_t
//	GripperMoveGlobal.TargetRotate =	-100;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-1180;//int32_t
//	GripperMoveGlobal.TargetRotate =	-90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
//	
//	
//	
//	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////��תƿ��
//	
////////////////////////XY�ƶ�λ������/////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	XYmoveGlobal.TargetX = 	BOTTLE_X;//int32_t
//	XYmoveGlobal.TargetY = 	BOTTLE_Y;
//	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
//	StepperSetting(&M1SettingGlobal);
//	StepperSetting(&M2SettingGlobal);
///////////////////////////////////////////////////////////////

//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-600;//int32_t
//	GripperMoveGlobal.TargetRotate =	-90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-600;//int32_t
//	GripperMoveGlobal.TargetRotate =	90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	
////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-1000;//int32_t
//	GripperMoveGlobal.TargetRotate =	90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////
//	

//	
//	
//	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////�÷�ƿ��

////////////////////////XY�ƶ�λ������/////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	XYmoveGlobal.TargetX = 	100;//int32_t
//	XYmoveGlobal.TargetY = 	0;
//	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
//	StepperSetting(&M1SettingGlobal);
//	StepperSetting(&M2SettingGlobal);
///////////////////////////////////////////////////////////////

////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-600;//int32_t
//	GripperMoveGlobal.TargetRotate =	90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////

////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-600;//int32_t
//	GripperMoveGlobal.TargetRotate =	-90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////

////////////////////////��צ�ƶ�λ������////////////////////////
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	if(DeveloperModelFLAG){
//		while(K_CON==0){
//			if(K_BAKcnt){DeveloperModelFLAG = 0;}
//		}
//	}else{
//		if(K_BAKcnt){DeveloperModelFLAG = 1;}
//	}
//	K_BAKcnt = 0;
//	
//	GripperMoveGlobal.TargetZ = 		-800;//int32_t
//	GripperMoveGlobal.TargetRotate =	-90;
//	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
//	StepperSetting(&M3SettingGlobal);
//	StepperSetting(&M4SettingGlobal);
//	Gripper_state = ENABLE ;
///////////////////////////////////////////////////////////////



	
//////////////////////////////////////////////////////////////////////////////////////////////////////////��λ

Stop_and_Reset:

//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 	-1000;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////

//////////////////////XY�ƶ�λ������/////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	XYmoveGlobal.TargetX = 	0;//int32_t
	XYmoveGlobal.TargetY = 	0;
	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
	StepperSetting(&M1SettingGlobal);
	StepperSetting(&M2SettingGlobal);
/////////////////////////////////////////////////////////////
	
//////////////////////��צ�ƶ�λ������////////////////////////
	while(M1M2_GetEN()==0){}
	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
	if(DeveloperModelFLAG){
		while(K_CON==0){
			if(K_BAKcnt){DeveloperModelFLAG = 0;}
		}
	}else{
		if(K_BAKcnt){DeveloperModelFLAG = 1;}
	}
	K_BAKcnt = 0;
	
	GripperMoveGlobal.TargetZ = 		0;//int32_t
	GripperMoveGlobal.TargetRotate =	0;
	UpDate_GripperMoveTarget(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
	StepperSetting(&M3SettingGlobal);
	StepperSetting(&M4SettingGlobal);
	Gripper_state = ENABLE ;
/////////////////////////////////////////////////////////////
	
	
//	while(M1M2_GetEN()==0){}
//	while(Gripper_state == ENABLE){if(M3_State == DISABLE&&M4_State == DISABLE){Gripper_state = DISABLE;}}
//	PumpCmd(DISABLE);
//	BoutCmd(DISABLE);

	while (1)
	{
		

	}
}

void TIM1_UP_IRQHandler(void)//TIM1�жϷ�����
{ 	    	  	     
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
	{
		Key_GetStatue(&K_BAK , &K_PSH , &K_CON);//��������1�����������0
		
		//������������
		if(K_BAK){K_BAKcnt++;}
		if(K_PSH){K_PSHcnt++;}
		if(K_CON){K_CONcnt++;}
		
		Encoder_Get(&EncoderSpeed);//����EncoderSpeed�ƴ�
		
		TIM1_CNT++;
		if(TIM1_CNT % 10 == 0){//T = 100ms
			TIM2_state = 0;
			TIM3_state = 0;
			
//			K_BAKcnt = 0;
//			K_PSHcnt = 0;
//			K_CONcnt = 0;
			
//	XYmoveGlobal.TargetX = 	XYmoveGlobal.TargetX+(int32_t)EncoderSpeed;
//	UpDate_XYmoveTarget(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
//	M1_State = ENABLE;
//	M3_State = ENABLE;
//	StepperTimerAutoCmd();
			menu_Clear();
//			GetBallPosition(&Ball_x,&Ball_y,&BallNum);
			menu_printf("(%d,%d) num:%d", cx,cy,BallNum);
			menu_printf("(%d,%d)",Ball_x,Ball_y);
			UpDate_XYCurrentPosition(&XYmoveGlobal , &M1SettingGlobal , &M2SettingGlobal);
			menu_printf("(%d,%d)", XYmoveGlobal.CurrentX,XYmoveGlobal.CurrentY);
			UpDate_GripperCurrentPosition(&GripperMoveGlobal , &M3SettingGlobal , &M4SettingGlobal);
			menu_printf("Z %d R %d", GripperMoveGlobal.CurrentZ,GripperMoveGlobal.CurrentRotate);

			OLED_Printf(116, 48, OLED_6X8, "%d", EncoderSpeed);
			OLED_Printf(116, 56, OLED_6X8, "%2u", FPS);
			FPS_CNT++;
			menu_Update();
			
			if(TIM1_CNT >= 100){//T = 1000ms
				
				MoveTimeCnt++;
				
				M1_ActualVelocity = 0;
				M2_ActualVelocity = 0;
				FPS = FPS_CNT;
				FPS_CNT = 0;
				TIM1_CNT = 0;
			}
			
		}
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);	//����жϱ�־λ
	}
}


void TIM2_IRQHandler(void) 
{ 
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) 	//TIM_IT_Update
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 	//����жϱ�־λ
		
		if(M1M2_GetEN() == 0){
			if(TIM_GetCapture3(TIM2) != 0){
				TIM2_state = 1;
				M1_ActualVelocity ++;
				M1_LastGap = M1_GapCNT;
				M1_GapCNT = 0;
				if(M1_GetDIR()){
				M1SettingGlobal.PulseCnt ++;
				}else{
				M1SettingGlobal.PulseCnt --;
				}
			}else{
				M1_GapCNT++;
//				if(M1_PulseGap == 0){
//					TIM_SetCompare3(TIM2, (uint16_t)(M1_ARR/2));
//				}else{
//					M1_PulseGap --;
//				}
			}
		}
		
		if(M3M4_GetEN() == 0){
			if(TIM_GetCapture4(TIM2) != 0){
				TIM2_state = 1;
				M3_LastGap = M3_GapCNT;
				M3_GapCNT = 0;
				if(M3_GetDIR()){
				M3SettingGlobal.PulseCnt ++;
				}else{
				M3SettingGlobal.PulseCnt --;
				}
			}else{
				M3_GapCNT++;
			}
		}

//		if(M1_GapCNT == 0 && M1SettingGlobal.StepperAcc != 0){
//			M1_StartDistance = (uint32_t)abs((int)(M1_StartPoint - M1SettingGlobal.PulseCnt));
//			M1_TargetDistance = (uint32_t)abs((int)(M1SettingGlobal.TargetPulseNum - M1SettingGlobal.PulseCnt));
//			if(M1SettingGlobal.StepperAcc >= M1_StartDistance || M1SettingGlobal.StepperAcc >= M1_TargetDistance)
//			{
//				if(M1_StartDistance < M1_TargetDistance){
//					M1_PulseGap = M1_LastGap-1;
//				}else if(M1_StartDistance > M1_TargetDistance){
//					M1_PulseGap = M1_LastGap+1;
//				}else{
//					M1_PulseGap = M1_LastGap;
//				}
//				TIM_SetCompare3(TIM2, 0);
//			}
//		}
		
		if(M1SettingGlobal.TargetPulseNum > M1SettingGlobal.PulseCnt + PulseRange){
			M1_DIR(1);M1M2_EN(0);
			TIM_SetCompare3(TIM2, (uint16_t)(M1_ARR/2));}
		else if(M1SettingGlobal.TargetPulseNum < M1SettingGlobal.PulseCnt - PulseRange){
			M1_DIR(0);M1M2_EN(0);
			TIM_SetCompare3(TIM2, (uint16_t)(M1_ARR/2));
		}else{
			M1_StartPoint = M1SettingGlobal.PulseCnt;
			TIM_SetCompare3(TIM2, 0);
			if(M1_GapCNT > 2*M1SettingGlobal.StepperAcc && M1_GapCNT > 50){
				M1_PulseGap = 0;
				M1_GapCNT = M1SettingGlobal.StepperAcc;
				M1SettingGlobal.StepperState = DISABLE;
				M1_State = DISABLE;
				StepperTimerAutoCmd();
			}
		}
		
		if(M3SettingGlobal.TargetPulseNum > M3SettingGlobal.PulseCnt){
			M3_DIR(1);
			TIM_SetCompare4(TIM2, (uint16_t)(M3_ARR/2));
		}else if(M3SettingGlobal.TargetPulseNum < M3SettingGlobal.PulseCnt){
			M3_DIR(0);
			TIM_SetCompare4(TIM2, (uint16_t)(M3_ARR/2));
		}else{
			M3_StartPoint = M3SettingGlobal.PulseCnt;
			TIM_SetCompare4(TIM2, 0);
			if(M3_GapCNT > 2*M3SettingGlobal.StepperAcc && M3_GapCNT > 300){
				M3_PulseGap = 0;
				M3_GapCNT = M3SettingGlobal.StepperAcc;
				M3SettingGlobal.StepperState = DISABLE;
				M3_State = DISABLE;
			}
		}
    }
} 

void TIM3_IRQHandler(void) 
{ 
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) 	//TIM_IT_Update
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update); 	//����жϱ�־λ
		
		if(M1M2_GetEN() == 0){
			if(TIM_GetCapture3(TIM3) != 0){
				TIM3_state = 1;
				M2_ActualVelocity ++;
				M2_LastGap = M2_GapCNT;
				M2_GapCNT = 0;
				if(M2_GetDIR()){
				M2SettingGlobal.PulseCnt ++;
				}else{
				M2SettingGlobal.PulseCnt --;
				}
			}else{
				M2_GapCNT++;
//				if(M2_PulseGap == 0){
//					TIM_SetCompare3(TIM3, (uint16_t)(M2_ARR/2));
//				}else{
//					M2_PulseGap --;
//				}
			}
		}
		
		if(M3M4_GetEN() == 0){
			if(TIM_GetCapture4(TIM3) != 0){
				TIM3_state = 1;
				M4_LastGap = M4_GapCNT;
				M4_GapCNT = 0;
				if(M4_GetDIR()){
				M4SettingGlobal.PulseCnt ++;
				}else{
				M4SettingGlobal.PulseCnt --;
				}
			}else{
				M4_GapCNT++;
			}
		}
		
//		if(M2_GapCNT == 0 && M2SettingGlobal.StepperAcc != 0){
//			M2_StartDistance = (uint32_t)abs((int)(M2_StartPoint - M2SettingGlobal.PulseCnt));
//			M2_TargetDistance = (uint32_t)abs((int)(M2SettingGlobal.TargetPulseNum - M2SettingGlobal.PulseCnt));
//			if(M2SettingGlobal.StepperAcc >= M2_StartDistance || M2SettingGlobal.StepperAcc >= M2_TargetDistance)
//			{
//				if(M2_StartDistance < M2_TargetDistance){
//					M2_PulseGap = M2_LastGap-1;
//				}else if(M2_StartDistance > M2_TargetDistance){
//					M2_PulseGap = M2_LastGap+1;
//				}else{
//					M2_PulseGap = M2_LastGap;
//				}
//				TIM_SetCompare3(TIM3, 0);
//			}
//		}
		
		if(M2SettingGlobal.TargetPulseNum > M2SettingGlobal.PulseCnt + PulseRange){
			M2_DIR(1);M1M2_EN(0);
			TIM_SetCompare3(TIM3, (uint16_t)(M2_ARR/2));
		}else if(M2SettingGlobal.TargetPulseNum < M2SettingGlobal.PulseCnt - PulseRange){
			M2_DIR(0);M1M2_EN(0);
			TIM_SetCompare3(TIM3, (uint16_t)(M2_ARR/2));
		}else{
			M2_StartPoint = M2SettingGlobal.PulseCnt;
			TIM_SetCompare3(TIM3, 0);
			if(M2_GapCNT > 2*M2SettingGlobal.StepperAcc && M2_GapCNT > 50){
				M2_PulseGap = 0;
				M2_GapCNT = M2SettingGlobal.StepperAcc;
				M2SettingGlobal.StepperState = DISABLE;
				M2_State = DISABLE;
				StepperTimerAutoCmd();
			}
		}
		
		if(M4SettingGlobal.TargetPulseNum > M4SettingGlobal.PulseCnt){
			M4_DIR(1);
			TIM_SetCompare4(TIM3, (uint16_t)(M4_ARR/2));
		}else if(M4SettingGlobal.TargetPulseNum < M4SettingGlobal.PulseCnt){
			M4_DIR(0);
			TIM_SetCompare4(TIM3, (uint16_t)(M4_ARR/2));
		}else{
			M4_StartPoint = M4SettingGlobal.PulseCnt;
			TIM_SetCompare4(TIM3, 0);
			if(M4_GapCNT > 2*M4SettingGlobal.StepperAcc && M4_GapCNT > 300){
				M4_PulseGap = 0;
				M4_GapCNT = M4SettingGlobal.StepperAcc;
				M4SettingGlobal.StepperState = DISABLE;
				M4_State = DISABLE;
			}
		}
		
    }
} 
