#include "stm32f10x.h"                  // Device header
#include "TB6612.h"

#define	GPIO_AIN1(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_12, (BitAction)x);
#define	GPIO_AIN2(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_11, (BitAction)x);
#define	GPIO_BIN1(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)x);
#define	GPIO_BIN2(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)x);

#define	GPIO_PWMA(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)x);
#define	GPIO_PWMB(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)x);

void TB6612_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOA, GPIO_Pin_12|GPIO_Pin_11);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOB, GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);
}


void A_DC_MotorRotation(Direction_t Direction)
{
	if(Direction == FORWARD)
	{GPIO_AIN1(1);GPIO_AIN2(0);}else
	{GPIO_AIN1(0);GPIO_AIN2(1);}
}

void B_DC_MotorRotation(Direction_t Direction)
{
	if(Direction == FORWARD)
	{GPIO_BIN1(1);GPIO_BIN2(0);}else
	{GPIO_BIN1(0);GPIO_BIN2(1);}
}


void PumpCmd(FunctionalState NewState)
{
	if(NewState == ENABLE)
	{GPIO_PWMA(1);}else
	{GPIO_PWMA(0);GPIO_AIN1(0);GPIO_AIN2(0);}
}

void BoutCmd(FunctionalState NewState)
{
	if(NewState == ENABLE)
	{GPIO_PWMB(1);}else
	{GPIO_PWMB(0);GPIO_BIN1(0);GPIO_BIN2(0);}
}
