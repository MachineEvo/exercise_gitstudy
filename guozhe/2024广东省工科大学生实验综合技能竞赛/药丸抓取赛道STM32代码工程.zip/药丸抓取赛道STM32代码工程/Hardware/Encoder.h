#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
void Encoder_Get(int16_t* EncoderSpeed);//����EncoderSpeed�ƴ�

#endif
