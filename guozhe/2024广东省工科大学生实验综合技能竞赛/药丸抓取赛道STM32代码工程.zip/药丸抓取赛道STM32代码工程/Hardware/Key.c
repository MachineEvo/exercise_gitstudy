#include "stm32f10x.h"                  // Device header
#include "Key.h"

//K_BAK		B12
//K_PSH		B15
//K_CON		A8

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void Key_GetStatue(uint8_t* K_BAK , uint8_t* K_PSH , uint8_t* K_CON)//��������1�����������0
{
	static uint8_t	ExK_BAKnum = 1,ExK_PSHnum = 1,ExK_CONnum = 1;
	if(K_BAKnum() == 0 && ExK_BAKnum == 1 )
	{*K_BAK = 1;}else
	{*K_BAK = 0;}
	ExK_BAKnum = K_BAKnum();
	if(K_PSHnum() == 0 && ExK_PSHnum == 1 )
	{*K_PSH = 1;}else
	{*K_PSH = 0;}
	ExK_PSHnum = K_PSHnum();
	if(K_CONnum() == 0 && ExK_CONnum == 1 )
	{*K_CON = 1;}else
	{*K_CON = 0;}
	ExK_CONnum = K_CONnum();
}
