#include "OPENMV.h"
#include "Serial.h"
int openmv[9];//stm32������������
int16_t cx;
int16_t cy;
int16_t ball_num;
uint8_t color[3] = {0x0C,0x05,0x6b};
uint8_t ball[3]  = {0x0C,0x04,0x6b};
uint8_t red[3]   = {0x0C,0x01,0x6b};
uint8_t blue[3]  = {0x0C,0x02,0x6b};
uint8_t green[3] = {0x0C,0x03,0x6b};
uint8_t reset[3] = {0x0C,0xff,0x6b};
uint8_t paulsed[3] = {0x0C,0x06,0x6b};
uint8_t continued[3] = {0x0C,0x07,0x6b};

//320*240	���Ͻ�(0,0)

#define	  BallArr1_x	  (Ball_2_x - Ball_1_x)
#define	  BallArr1_y	  (Ball_2_y - Ball_1_y)
#define	SensorArr1_x	(Sensor_2_x - Sensor_1_x)
#define	SensorArr1_y	(Sensor_2_y - Sensor_1_y)

//#define	  BallArr2_x	  Ball_3_x - Ball_1_x
//#define	  BallArr2_y	  Ball_3_y - Ball_1_y
//#define	SensorArr2_x	Sensor_3_x - Sensor_1_x
//#define	SensorArr2_y	Sensor_3_y - Sensor_1_y

///*�������
//|Drift_11	Drift_12|
//|					|
//|Drift_21	Drift_22|
//*/
//#define	Drift_11	((float)BallArr1_x * SensorArr2_y - BallArr2_x * SensorArr1_y)/((float)SensorArr1_x * SensorArr2_y - SensorArr2_x * SensorArr1_y)
//#define	Drift_12	((float)BallArr1_x * SensorArr2_x - BallArr2_x * SensorArr1_x)/((float)SensorArr2_x * SensorArr1_y - SensorArr1_x * SensorArr2_y)
//#define	Drift_21	((float)BallArr1_y * SensorArr2_y - BallArr2_y * SensorArr1_y)/((float)SensorArr2_x * SensorArr1_y - SensorArr1_x * SensorArr2_y)
//#define	Drift_22	((float)BallArr1_y * SensorArr2_x - BallArr2_y * SensorArr1_x)/((float)SensorArr2_x * SensorArr1_y - SensorArr1_x * SensorArr2_y)


void GetBallPosition(int32_t* Ball_x,int32_t* Ball_y,uint8_t* BallNum)
{
	static int16_t Last_cx = 0,Last_cy = 0;
	
	if(cx != 0 && cy != 0 && (ball_num != 0 || BallMove_theshold>((Last_cx - cx)*(Last_cx - cx)+(Last_cy - cy)*(Last_cy - cy)))){
		int16_t Arr_cx=0,Arr_cy=0;
		int32_t ArrBall_x,ArrBall_y;
		
		Arr_cx=cx - (int16_t)Sensor_1_x;
		Arr_cy=cy - (int16_t)Sensor_1_y;
		
		ArrBall_x = (int32_t)((float)Arr_cx*BallArr1_x/SensorArr1_x);
		ArrBall_y = (int32_t)((float)Arr_cy*BallArr1_y/SensorArr1_y);
		
		*Ball_x = ArrBall_x + (int32_t)Ball_1_x;
		*Ball_y = ArrBall_y + (int32_t)Ball_1_y;
	}else{
		*Ball_x = 0;
		*Ball_y = 0;
	}
	*BallNum = ball_num;
	Last_cx = cx;
	Last_cy = cy;
}


int i=0;
 
void Openmv_Receive_Data(int16_t data)//����Openmv������������
{
	static u8 state = 0;
	if(state==0&&data==0x2C)
	{
		state=1;
		openmv[0]=data;
	}
	else if(state==1&&data==0x12)
	{
		state=2;
		openmv[1]=data;
	}
	else if(state==2)
	{
		state=3;
		openmv[2]=data;
	}
	else if(state==3)
	{
		state = 4;
		openmv[3]=data;
	}
	else if(state==4)
	{
        state = 5;
        openmv[4]=data;
	}
	else if(state==5)
	{
        state = 6;
        openmv[5]=data;
	}
	else if(state==6)		//����Ƿ���ܵ�������־
	{
		state = 7;
        openmv[6]=data;
	}
	else if(state==7)
	{
        state = 8;
        openmv[7]=data;
	}
	else if(state==8)
	{
		openmv[8]=data;
        if(data == 0x5B)
        {
            state = 0;
            openmv[8]=data;
            Openmv_Data();
        }
        else if(data != 0x5B)
        {
            state = 0;
            for(i=0;i<9;i++)
            {
                openmv[i]=0x00;
            }           
        }
	}
	else
	{
		state = 0;
		for(i=0;i<9;i++)
		{
			openmv[i]=0x00;
		}
	}
}
 
void Openmv_Data(void)
{
    cx=openmv[2];
    cy=openmv[4];
	ball_num=openmv[6];
}


void Recognize_color(void)
{
	Serial_SendArray(color,3);
}

void Recognize_ball(void)
{
	Serial_SendArray(ball,3);
}

void Color_red(void)
{
	Serial_SendArray(red,3);
}

void Color_blue(void)
{
	Serial_SendArray(blue,3);
}

void Color_green(void)
{
	Serial_SendArray(green,3);
}

void Reset(void)
{
	Serial_SendArray(reset,3);
}

void Paulsed(void)
{
	Serial_SendArray(paulsed,3);
}


void Continued(void)
{
	Serial_SendArray(continued,3);
}
