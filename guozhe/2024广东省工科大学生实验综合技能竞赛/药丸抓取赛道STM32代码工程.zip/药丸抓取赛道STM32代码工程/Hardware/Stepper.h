#ifndef __STEPPER_H
#define __STEPPER_H
#include "stm32f10x.h"                  // Device header
#include "Timer.h"
#include "LED.h"
#include <stdlib.h>

#define	M1_DIR(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_4, (BitAction)x)
#define	M2_DIR(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_5, (BitAction)x)
#define	M3_DIR(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_6, (BitAction)x)
#define	M4_DIR(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_7, (BitAction)x)

#define	M1_GetDIR()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)
#define	M2_GetDIR()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)
#define	M3_GetDIR()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6)
#define	M4_GetDIR()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7)

#define	M1M2_EN(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_0, (BitAction)x)
#define	M3M4_EN(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_1, (BitAction)x)

#define	M1M2_GetEN()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)
#define	M3M4_GetEN()	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)

#define REFERENCE_DIV	DIV1

/*********�������ö��**********/
typedef enum {
    StepperM1 = 0,
	StepperM2,
    StepperM3,
	StepperM4,
}StepperSellect_t;

///********�������ͨ��ö��*********/
//typedef enum {
//    Channel1 = 0,
//    Channel2,
//    Channel3,
//    Channel4,
//}PWMChannelSellect_t;

/***********ϸ��ö��***********/
typedef enum {
    DIV1  = 1 ,
    DIV2  = 2 ,
    DIV4  = 4 ,
    DIV8  = 8 ,
    DIV16 = 16,
    DIV64 = 64,
    DIV128=128,
}DivSellect_t;

///***********ʱ��ö��***********/
//typedef enum {
//    Timer1 = 1 ,
//    Timer2,
//    Timer3,
//    Timer4,
//    Timer5,
//    Timer6,
//    Timer7,
//    Timer8,
//}TIM_Type_t;

/********������������ӿ�*********/
typedef struct{
    StepperSellect_t	StepperSellect;		//�������ѡ��
	FunctionalState		StepperState;	//״̬ѡ��
    DivSellect_t	DivSellect;		//ϸ�ִ�С
    int32_t 		StepperSpeed;	//�ٶȣ�Stp/s��
	uint32_t		StepperAcc;		//���ٶȣ�Stp/s**2��
	int32_t		TargetPulseNum;	//Ŀ��������
	int32_t		PulseCnt;		//�������
//	PWMChannelSellect_t	PWMChannelSellect;	//�������ͨ��ѡ��
//	TIM_Type_t 		TimerX;			//ʱ��ѡ��
//	uint16_t		PSC;
//	uint16_t		ARR;
}StepperSettingDef;

void Stepper_Init(void);//M1:T2C3  M2:T3C3  M3:T2C4  M4:T3C4  //42 ARR=50 PSC=45 T=200ms 8ϸ��R=12.2/2

void StepperSetting(StepperSettingDef *StepperSettingStructure);
void StepperTimerAutoCmd(void);
void StepperCmd (StepperSettingDef *StepperSettingStructure);

//#include <stbool>
//#include <stdint.h>
//#include <stdio.h>

//DIR1	PA4
//DIR2	PA5
//DIR3	PA6
//DIR4	PA7

//M1	T2C3	PA2
//M2	T3C3	PB0
//M3	T2C4	PA3
//M4	T3C4	PB1

//DIV1	8
//DIV2	8
//DIV3	8
//DIV4	8

//ENA(M1M2)	PA0
//ENB(M3M4)	PA1


//_Bool UpdatePluseCnt(StepperSettingDef *StepperSettingStructure);

//int32_t M1M3_SetSpeed(uint16_t StepperSpeed,uint8_t DIV);//TIM2//StepperSpeed!=0,<65536
//int32_t M2M4_SetSpeed(uint16_t StepperSpeed,uint8_t DIV);//TIM3//StepperSpeed!=0,<65536

#endif
 
