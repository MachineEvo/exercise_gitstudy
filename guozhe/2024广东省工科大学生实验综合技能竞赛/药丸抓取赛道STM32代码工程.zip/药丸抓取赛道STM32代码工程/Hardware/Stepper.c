#include "stm32f10x.h"                  // Device header
#include "Stepper.h"

//#define TIMER_PSC	72
#define MAX_ARR		8192	//8192 = 2**13
#define MPU_SPEED	72000000

uint16_t TIM_PSCReloadMode = TIM_PSCReloadMode_Update;//定时器装载模式		TIM_PSCReloadMode_Immediate

uint16_t M1_ARR = 0, M1_PSC = 0,
		 M2_ARR = 0, M2_PSC = 0,
		 M3_ARR = 0, M3_PSC = 0,
		 M4_ARR = 0, M4_PSC = 0;
		 
uint8_t M1_State = DISABLE,
		M2_State = DISABLE,
		M3_State = DISABLE,
		M4_State = DISABLE;

void Stepper_Init(void)//M1:T2C3  M2:T3C3  M3:T2C4  M4:T3C4  //42 ARR=50 PSC=45 T=200ms 8细分R=12.2/2
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 |GPIO_Pin_0|GPIO_Pin_1);
	
	Timer2_Init(50 , 45);
	Timer3_Init(50 , 45);
}

void SpeedCalc(uint16_t* StepperSpeed,uint8_t* DIV,uint16_t* ARR,uint16_t* PSC)
{
	static uint32_t PulseSpeed;
	PulseSpeed = (uint32_t)((*StepperSpeed) * ( (*DIV) / REFERENCE_DIV));
	if(MPU_SPEED <= MAX_ARR*PulseSpeed ){
		*PSC = 1;
		*ARR = (uint16_t)((float)MPU_SPEED/PulseSpeed);
	}else if(PulseSpeed == 0){
		*ARR = 0;
		*PSC = 65535;
	}else{
		*ARR = MAX_ARR;
		*PSC = (uint16_t)((float)MPU_SPEED/(MAX_ARR*PulseSpeed));
	}
}


void StepperSetting(StepperSettingDef *StepperSettingStructure)
{
	static uint16_t StepperSpeed_Fnc = 0;
	static uint8_t Div = 0 , DIR_Flag = 0;
	
	Div = StepperSettingStructure->DivSellect;
	if(StepperSettingStructure->TargetPulseNum == StepperSettingStructure->PulseCnt)
	{
		StepperSettingStructure->StepperState = DISABLE;
	}else{
		StepperSettingStructure->StepperState = ENABLE;
	}
	
	if(StepperSettingStructure->StepperSpeed == 0){
		StepperSpeed_Fnc = 0;
	}else if(StepperSettingStructure->StepperSpeed < 0){
		DIR_Flag = 0;
		StepperSpeed_Fnc = (uint16_t)(- (StepperSettingStructure->StepperSpeed) );
	}else if(StepperSettingStructure->StepperSpeed > 0){
		DIR_Flag = 1;
		StepperSpeed_Fnc = (uint16_t)(   StepperSettingStructure->StepperSpeed  );
	}
	
	switch(StepperSettingStructure->StepperSellect){//M1:T2C3  M2:T3C3  M3:T2C4  M4:T3C4
		case StepperM1:
			SpeedCalc(&StepperSpeed_Fnc, &Div, &M1_ARR, &M1_PSC);
			TIM_Cmd(TIM2, DISABLE);
			if(DIR_Flag){M1_DIR(1);}
			else{		 M1_DIR(0);}
			TIM_PrescalerConfig(TIM2, M1_PSC, TIM_PSCReloadMode);
			TIM_SetAutoreload(TIM2, M1_ARR);
			TIM_SetCompare3(TIM2, (uint16_t)(M1_ARR/2));
			M1_State = StepperSettingStructure->StepperState;
			break;
		case StepperM2:
			SpeedCalc(&StepperSpeed_Fnc, &Div, &M2_ARR, &M2_PSC);
			TIM_Cmd(TIM3, DISABLE);
			if(DIR_Flag){M2_DIR(1);}
			else{		 M2_DIR(0);}
			TIM_PrescalerConfig(TIM3, M2_PSC, TIM_PSCReloadMode);
			TIM_SetAutoreload(TIM3, M2_ARR);
			TIM_SetCompare3(TIM3, (uint16_t)(M2_ARR/2));
			M2_State = StepperSettingStructure->StepperState;
			break;
		case StepperM3:
			SpeedCalc(&StepperSpeed_Fnc, &Div, &M3_ARR, &M3_PSC);
			TIM_Cmd(TIM2, DISABLE);
			if(DIR_Flag){M3_DIR(1);}
			else{		 M3_DIR(0);}
			TIM_PrescalerConfig(TIM2, M3_PSC, TIM_PSCReloadMode);
			TIM_SetAutoreload(TIM2, M3_ARR);
			TIM_SetCompare4(TIM2, (uint16_t)(M3_ARR/2));
			M3_State = StepperSettingStructure->StepperState;
			break;
		case StepperM4:
			SpeedCalc(&StepperSpeed_Fnc, &Div, &M4_ARR, &M4_PSC);
			TIM_Cmd(TIM3, DISABLE);
			if(DIR_Flag){M4_DIR(1);}
			else{		 M4_DIR(0);}
			TIM_PrescalerConfig(TIM3, M4_PSC, TIM_PSCReloadMode);
			TIM_SetAutoreload(TIM3, M4_ARR);
			TIM_SetCompare4(TIM3, (uint16_t)(M4_ARR/2));
			M4_State = StepperSettingStructure->StepperState;
			break;
	}
	
	StepperTimerAutoCmd();
}

void StepperTimerAutoCmd(void)
{
	if(M1_State == ENABLE | M2_State == ENABLE){
		M1M2_EN(0);
		LED_ON();
	}else{
		M1M2_EN(1);
		LED_OFF();
	}
	if(M3_State == ENABLE | M4_State == ENABLE){
		M3M4_EN(0);
	}else{      
//		M3M4_EN(1);
	}
	if(M1_State == ENABLE | M3_State == ENABLE){
		TIM_Cmd(TIM2, ENABLE);
	}else{      
		TIM_Cmd(TIM2, DISABLE);
	}
	if(M2_State == ENABLE | M4_State == ENABLE){
		TIM_Cmd(TIM3, ENABLE);
	}else{      
		TIM_Cmd(TIM3, DISABLE);
	}
}

void StepperCmd (StepperSettingDef *StepperSettingStructure)
{
	if(StepperSettingStructure->StepperState == ENABLE){
	switch(StepperSettingStructure->StepperSellect){
		case StepperM1:
			TIM_SetCompare3(TIM2, (uint16_t)(M1_ARR/2));
			break;
		case StepperM2:
			TIM_SetCompare3(TIM3, (uint16_t)(M2_ARR/2));
			break;
		case StepperM3:
			TIM_SetCompare4(TIM2, (uint16_t)(M3_ARR/2));
			break;
		case StepperM4:
			TIM_SetCompare4(TIM3, (uint16_t)(M4_ARR/2));
			break;
	}}else{
	switch(StepperSettingStructure->StepperSellect){
		case StepperM1:
			TIM_SetCompare3(TIM2, 0);
			break;
		case StepperM2:
			TIM_SetCompare3(TIM3, 0);
			break;
		case StepperM3:
			TIM_SetCompare4(TIM2, 0);
			break;
		case StepperM4:
			TIM_SetCompare4(TIM3, 0);
			break;
	}}
	switch(StepperSettingStructure->StepperSellect){
		case StepperM1:
			M1_State = StepperSettingStructure->StepperState;
			break;
		case StepperM2:
			M2_State = StepperSettingStructure->StepperState;
			break;
		case StepperM3:
			M3_State = StepperSettingStructure->StepperState;
			break;
		case StepperM4:
			M4_State = StepperSettingStructure->StepperState;
			break;
	}
	StepperTimerAutoCmd();
}


//_Bool UpdatePluseCnt(StepperSettingDef *StepperSettingStructure)
//{
//	StepperSettingStructure->PulseCnt ++;
//	
//	return 1;
//}

//int32_t  M1M3_SetSpeed(uint16_t StepperSpeed,uint8_t DIV)//TIM2//StepperSpeed!=0,<65536
//{
//	static uint16_t ARR, PSC;
//	static uint32_t PulseSpeed;
//	PulseSpeed = (uint32_t)(StepperSpeed * (DIV/DIV8));
//	if(MPU_SPEED > MAX_ARR*PulseSpeed ){
//		ARR = MAX_ARR;
//		PSC = (uint16_t)((float)MPU_SPEED/(MAX_ARR*PulseSpeed));
//	}else{
//		PSC = 1;
//		ARR = (uint16_t)(MPU_SPEED/(float)PulseSpeed);
//	}
//	
//	TIM_InternalClockConfig(TIM2);
//		
//	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
//	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
//	TIM_TimeBaseInitStructure.TIM_Period = ARR - 1;		//ARR
//	TIM_TimeBaseInitStructure.TIM_Prescaler = PSC - 1;		//PSC
//	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
//	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
//	
//	TIM_ClearFlag(TIM2, TIM_FLAG_Update);
//	
//	TIM_SetCompare3(TIM2, (uint16_t)(ARR/2));
//	TIM_SetCompare4(TIM2, (uint16_t)(ARR/2));
//	
//	TIM_Cmd(TIM2, DISABLE);
//	
//	return (int32_t)PulseSpeed;
//}

//int32_t  M2M4_SetSpeed(uint16_t StepperSpeed,uint8_t DIV)//TIM3//StepperSpeed!=0,<65536
//{
//	static uint16_t ARR, PSC;
//	static uint32_t PulseSpeed;
//	PulseSpeed = (uint32_t)(StepperSpeed * (DIV/DIV8));
//	if(MPU_SPEED > MAX_ARR*PulseSpeed ){
//		ARR = MAX_ARR;
//		PSC = (uint16_t)((float)MPU_SPEED/(MAX_ARR*PulseSpeed));
//	}else{
//		PSC = 1;
//		ARR = (uint16_t)((float)MPU_SPEED/PulseSpeed);
//	}
//	
//	TIM_InternalClockConfig(TIM3);
//	
//	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
//	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
//	TIM_TimeBaseInitStructure.TIM_Period = ARR - 1;		//ARR
//	TIM_TimeBaseInitStructure.TIM_Prescaler = PSC - 1;		//PSC
//	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
//	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
//	
//	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
//	
//	TIM_SetCompare3(TIM3, (uint16_t)(ARR/2));
//	TIM_SetCompare4(TIM3, (uint16_t)(ARR/2));
//	
//	return (int32_t)PulseSpeed;
//}

//StepperSettingDef StepperSettingGlobal;

//void TIM2_IRQHandler(void) 
//{ 
//    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) 	//TIM_IT_Update
//    { 
//        TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 	//清除中断标志位 
//		StepperSettingGlobal.TargetPulseNum
//		StepperSettingGlobal.StepperAcc
//		StepperSettingGlobal.StepperSpeed
//		if(StepperSettingGlobal.NextPulseNum > StepperSettingGlobal.PulseCnt)
//		{
//			StepperSettingGlobal.PulseCnt ++;
//			TIM_SetCompare3(TIM3, (uint16_t)(ARR/2));
//		StepperSettingGlobal.PulseCnt
//        TIM_CtrlPWMOutputs(TIM1, DISABLE);  			//主输出使能
//        TIM_Cmd(TIM1, DISABLE); 						//关闭定时器 
//        TIM_Cmd(TIM2, DISABLE); 						//关闭定时器 
//        TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE); 	//关闭TIM2更新中断
//        
//    } 
//} 
