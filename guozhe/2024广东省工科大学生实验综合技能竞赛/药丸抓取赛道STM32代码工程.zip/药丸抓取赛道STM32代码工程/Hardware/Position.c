#include "position.h"
//����__sqrtf()��sqrtf()

void XY_PositionReset(XYmoveDef *XYmove , StepperSettingDef *M1Setting , StepperSettingDef *M2Setting)
{
	XYmove->CurrentX = 0;
	XYmove->CurrentY = 0;
	XYmove->TargetX	 = 0;
	XYmove->TargetY	 = 0;
	
	M1Setting->PulseCnt			=0;
	M1Setting->StepperSpeed		=0;
	M1Setting->StepperState		=DISABLE;
	M1Setting->TargetPulseNum	=0;
	M1Setting->StepperAcc		=0;
	
	M2Setting->PulseCnt			=0;
	M2Setting->StepperSpeed		=0;
	M2Setting->StepperState		=DISABLE;
	M2Setting->TargetPulseNum	=0;
	M2Setting->StepperAcc		=0;
}

void GripperPositionReset(GripperMoveDef *GripperMove , StepperSettingDef *M3Setting , StepperSettingDef *M4Setting)
{
	GripperMove->CurrentRotate	=0;
	GripperMove->CurrentZ       =0;
	GripperMove->TargetRotate   =0;
	GripperMove->TargetZ        =0;
	
	M3Setting->PulseCnt			=0;
	M3Setting->StepperSpeed		=0;
	M3Setting->StepperState		=DISABLE;
	M3Setting->TargetPulseNum	=0;
	
	M4Setting->PulseCnt			=0;
	M4Setting->StepperSpeed		=0;
	M4Setting->StepperState		=DISABLE;
	M4Setting->TargetPulseNum	=0;
}

//void ParameterSetting()
//{
//	
//	
//	
//	
//	
//	
//}

void UpDate_XYmoveTarget(XYmoveDef *XYmove , StepperSettingDef *M1Setting , StepperSettingDef *M2Setting)
{
	static int32_t	Int32_t1_Fnc,Int32_t2_Fnc;
	static float	Float1_Fnc,Float2_Fnc;
	
	Int32_t1_Fnc = XYmove->TargetX + XYmove->TargetY;
	M1Setting->TargetPulseNum = (int32_t)( ((float)(M1Setting->DivSellect) / REFERENCE_DIV) * Int32_t1_Fnc );
	
	Int32_t2_Fnc = XYmove->TargetX - XYmove->TargetY;
	M2Setting->TargetPulseNum = (int32_t)( ((float)(M2Setting->DivSellect) / REFERENCE_DIV) * Int32_t2_Fnc );
	
	
	Float1_Fnc = (float)M1Setting->PulseCnt / M1Setting->DivSellect;
	Float2_Fnc = (float)M2Setting->PulseCnt / M2Setting->DivSellect;
	XYmove->CurrentX = (int32_t)( REFERENCE_DIV * (Float1_Fnc + Float2_Fnc));
	XYmove->CurrentY = (int32_t)( REFERENCE_DIV * (Float1_Fnc - Float2_Fnc));
	
	
	Int32_t1_Fnc = XYmove->TargetX - XYmove->CurrentX;
	Int32_t2_Fnc = XYmove->TargetY - XYmove->CurrentY;
	Float1_Fnc = (float)Int32_t1_Fnc*Int32_t1_Fnc + (float)Int32_t2_Fnc*Int32_t2_Fnc;
	if(Float1_Fnc < 1.0){
		Float1_Fnc = 1.0;
	}else{
		Float1_Fnc = sqrtf(Float1_Fnc);
	}
	
	M1Setting->StepperSpeed = (int32_t)( (float)(XYmove->MoveSpeed)*(Int32_t1_Fnc + Int32_t2_Fnc)/Float1_Fnc );
	M2Setting->StepperSpeed = (int32_t)( (float)(XYmove->MoveSpeed)*(Int32_t1_Fnc - Int32_t2_Fnc)/Float1_Fnc );
	
	
	if(M1Setting->StepperSpeed<0&&M1Setting->StepperSpeed>-100){
		M1Setting->StepperSpeed = -100;
	}
	if(M1Setting->StepperSpeed>0&&M1Setting->StepperSpeed<100){
		M1Setting->StepperSpeed = 100;
	}
	
	M1Setting->StepperAcc = (uint32_t)( (float)(XYmove->MoveAcc)*(Int32_t1_Fnc + Int32_t2_Fnc)/Float1_Fnc );
	M2Setting->StepperAcc = (uint32_t)( (float)(XYmove->MoveAcc)*(Int32_t1_Fnc - Int32_t2_Fnc)/Float1_Fnc );
}

void UpDate_XYCurrentPosition(XYmoveDef *XYmove , StepperSettingDef *M1Setting , StepperSettingDef *M2Setting)
{
	static float	Float1_Fnc,Float2_Fnc;
	Float1_Fnc = (float)M1Setting->PulseCnt / M1Setting->DivSellect;
	Float2_Fnc = (float)M2Setting->PulseCnt / M2Setting->DivSellect;
	XYmove->CurrentX = (int32_t)( (float)REFERENCE_DIV * (Float1_Fnc + Float2_Fnc));
	XYmove->CurrentY = (int32_t)( (float)REFERENCE_DIV * (Float1_Fnc - Float2_Fnc));
}


void UpDate_GripperMoveTarget(GripperMoveDef *GripperMove , StepperSettingDef *M3Setting , StepperSettingDef *M4Setting)
{	
	M3Setting->TargetPulseNum = (int32_t)( ((float)(M3Setting->DivSellect) / REFERENCE_DIV) * GripperMove->TargetZ );
	
	GripperMove->CurrentZ = (int32_t)( ((float)REFERENCE_DIV / (M3Setting->DivSellect)) * M3Setting->PulseCnt );
	
	M3Setting->StepperSpeed = (int32_t)( ((float)(M3Setting->DivSellect) / REFERENCE_DIV) * GripperMove->ZmoveSpeed );
	
	M3Setting->StepperAcc = 0;
	

	M4Setting->TargetPulseNum = (int32_t)( ((float)(M4Setting->DivSellect) / REFERENCE_DIV) * GripperMove->TargetRotate );
	
	GripperMove->CurrentRotate = (int32_t)( ((float)REFERENCE_DIV / (M4Setting->DivSellect)) * M4Setting->PulseCnt );
	
	M4Setting->StepperSpeed = (int32_t)( ((float)(M4Setting->DivSellect) / REFERENCE_DIV) * GripperMove->RotateSpeed );
	
	M4Setting->StepperAcc = 0;	
}

void UpDate_GripperCurrentPosition(GripperMoveDef *GripperMove , StepperSettingDef *M3Setting , StepperSettingDef *M4Setting)
{
	GripperMove->CurrentZ = (int32_t)( ((float)REFERENCE_DIV / (M3Setting->DivSellect)) * M3Setting->PulseCnt );
	
	GripperMove->CurrentRotate = (int32_t)( ((float)REFERENCE_DIV / (M4Setting->DivSellect)) * M4Setting->PulseCnt );
}


//void TIM2_IRQHandler(void) 
//{ 
//    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) 	//TIM_IT_Update
//    { 
//        TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 	//����жϱ�־λ 
//        TIM_CtrlPWMOutputs(TIM1, DISABLE);  			//�����ʹ��
//        TIM_Cmd(TIM1, DISABLE); 						//�رն�ʱ�� 
//        TIM_Cmd(TIM2, DISABLE); 						//�رն�ʱ�� 
//        TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE); 	//�ر�TIM2�����ж�
//        
//    } 
//} 
