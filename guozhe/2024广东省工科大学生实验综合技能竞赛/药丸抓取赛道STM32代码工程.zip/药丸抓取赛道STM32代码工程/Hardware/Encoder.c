#include "stm32f10x.h"                  // Device header

#define TRA()	GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)
#define TRB()	GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13)

void Encoder_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 |GPIO_Pin_14;
	
	GPIO_Init(GPIOB,&GPIO_InitStruct);
}

void Encoder_Get(int16_t* EncoderSpeed)//����EncoderSpeed�ƴ�
{
	static uint8_t	ExTRA = 0;

	if(TRA() == 0 && ExTRA == 1)
	{
		if(TRB() == 0)
		{
			*EncoderSpeed += 1;
		}else{
			*EncoderSpeed -= 1;
		}
	}
	ExTRA = TRA();
}
