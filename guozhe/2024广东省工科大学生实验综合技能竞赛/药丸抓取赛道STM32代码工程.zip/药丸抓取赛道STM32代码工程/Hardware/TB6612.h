#ifndef __TB6612_H
#define __TB6612_H
#include "stm32f10x.h"                  // Device header
#include <stdlib.h>
#include <stdio.h>

#define	GPIO_AIN1(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_12, (BitAction)x);
#define	GPIO_AIN2(x)	GPIO_WriteBit(GPIOA, GPIO_Pin_11, (BitAction)x);
#define	GPIO_PWMA(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)x);

#define	GPIO_BIN1(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)x);
#define	GPIO_BIN2(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)x);
#define	GPIO_PWMB(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)x);

typedef enum{
	FORWARD=0,
	REVERSE,
}Direction_t;

void TB6612_Init(void);

void A_DC_MotorRotation(Direction_t Direction);
void B_DC_MotorRotation(Direction_t Direction);

void PumpCmd(FunctionalState NewState);
void BoutCmd(FunctionalState NewState);

#endif
